
export default {
  mounted(el) {
    el.focus()
  }
}
