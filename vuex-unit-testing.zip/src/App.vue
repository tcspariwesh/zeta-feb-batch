
<template>
  <nav>
    <router-link to="/">Dashboard</router-link> |
    <router-link to="/books">Books</router-link> |
    <router-link to="/login">Login</router-link>
  </nav>
  <router-view />
</template>
